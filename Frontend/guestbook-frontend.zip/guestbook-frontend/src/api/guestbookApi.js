export const fetchGuestbookEntries = async () => {
  return [
    { id: 1, name: 'Anna', message: 'Hallo' },
    { id: 2, name: 'Lukas', message: 'Tschüss' },
  ];
};
