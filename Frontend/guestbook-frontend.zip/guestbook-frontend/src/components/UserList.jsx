import { useEffect, useState } from 'react'; // React Hooks importieren

/**
 * Zeigt alle registrierten Benutzer an.
 *
 * Lädt die Benutzerliste automatisch beim ersten Laden der Seite.
 * Zeigt entweder:
 * - eine Ladeanzeige
 * - eine Meldung bei leerer Liste
 * - oder alle Benutzernamen
 *
 * @component
 * @returns {JSX.Element}
 */
function Users() {
  // State für die Benutzerdaten
  const [users, setUsers] = useState([]);

  // State für Ladeanzeige (true = lädt noch)
  const [loading, setLoading] = useState(true);

  /**
   * useEffect wird direkt nach dem ersten Rendern aufgerufen.
   * [] bedeutet: dieser Effekt läuft nur einmal
   */
  useEffect(() => {
    // Hole die Benutzerdaten vom Backend
    fetch('http://localhost:8080/api/users')
      .then((res) => res.json()) // Antwort zu JSON parsen
      .then((data) => {
        setUsers(data);     // Benutzerliste speichern
        setLoading(false);  // Ladezustand auf "fertig" setzen
      })
      .catch((err) => {
        console.error("Fehler beim Laden der Benutzer:", err);
        setLoading(false);  // Auch bei Fehler: Ladezustand beenden
      });
  }, []); // leeres Array = nur beim ersten Laden der Komponente ausführen

  /**
   * JSX-Rückgabe:
   * Zeigt eine Karte mit 3 möglichen Zuständen:
   * 1. Wenn geladen wird "Lade Benutzer..."
   * 2. Wenn fertig, aber keine Benutzer "Keine Benutzer gefunden."
   * 3. Wenn Benutzer da Liste anzeigen
   */
  return (
    <div className="container">
      <h1>Alle Benutzer</h1>

      <div className="card">
        {loading ? ( // Wenn loading === true
          <p>Lade Benutzer...</p>
        ) : users.length === 0 ? ( // Wenn loading false UND Liste leer
          <p>Keine Benutzer gefunden.</p>
        ) : ( // Wenn Benutzer vorhanden sind
          <ul className="user-list">
            {users.map((user) => (
              <li key={user.id}>
                <strong>{user.name}</strong>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default Users;
