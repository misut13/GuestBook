import UserForm from '../components/UserForm';

function RegisterUser() {
  return (
    <div className="container">
      <h1>Konto erstellen</h1>
      <UserForm />
    </div>
  );
}

export default RegisterUser;
