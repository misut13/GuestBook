import GuestbookForm from '../components/GuestbookForm';

function NewEntry() {
  return (
    <div className="container">
      <h1>Neuen Eintrag verfassen</h1>
        <GuestbookForm />
    </div>
  );
}

export default NewEntry;
